# magento2-transactional-email
How to send an email from a custom module in Magento 2

# See the video about this practice
- Youtube: https://www.youtube.com/watch?v=L3ZbPCu0GXk&index=26&list=PL98CDCbI3TNvPczWSOnpaMoyxVISLVzYQ
- Facebook: https://www.facebook.com/giaphugroupcom/videos/2189196548070673/
